CREATE DATABASE LojaRoupas;
GO

USE LojaRoupas;
GO

CREATE TABLE CLIENTE (
    id_cliente INT IDENTITY(1,1) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    CPF VARCHAR(14) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL
);
GO

CREATE TABLE FUNCIONARIO (
    id_funcionario INT IDENTITY(1,1) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    CPF VARCHAR(14) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    cargo VARCHAR(50) NOT NULL
);
GO

CREATE TABLE PRODUTO (
    id_produto INT IDENTITY(1,1) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    tamanho VARCHAR(10) NOT NULL,
    cor VARCHAR(30) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL
);
GO

CREATE TABLE VENDA (
    id_venda INT IDENTITY(1,1) PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_funcionario INT NOT NULL,
    data_venda DATETIME NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_VENDA_CLIENTE
        FOREIGN KEY (id_cliente)
        REFERENCES CLIENTE(id_cliente),
    CONSTRAINT FK_VENDA_FUNCIONARIO
        FOREIGN KEY (id_funcionario)
        REFERENCES FUNCIONARIO(id_funcionario)
);
GO

CREATE TABLE ITEM_VENDA (
    id_item INT IDENTITY(1,1) PRIMARY KEY,
    id_venda INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_ITEM_VENDA
        FOREIGN KEY (id_venda)
        REFERENCES VENDA(id_venda),
    CONSTRAINT FK_ITEM_PRODUTO
        FOREIGN KEY (id_produto)
        REFERENCES PRODUTO(id_produto)
);
GO